// Skill Scraper - Dashboard Script
// Requires login to export, checks Supabase quota

function capitalizeFirstLetter(a) {
    return a.charAt(0).toUpperCase() + a.slice(1);
}

var table = newTabulator("#example-table", {
    layout: "fitData",
    placeholder: "Loading...",
    selectable: 1,
    downloadConfig: { undefinedString: "" }
});

// Check login and handle export
async function checkLoginAndExport(format) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            // Show login prompt
            document.getElementById('loginPrompt').style.display = 'flex';
            return;
        }

        const plan = await getUserPlan();
        if (!plan) {
            alert('Error loading plan info. Please try again.');
            return;
        }

        const remaining = plan.quota - (plan.used || 0);
        const rowCount = table.getRows().length;

        if (plan.plan !== 'enterprise' && remaining <= 0) {
            alert(`Export limit reached! You've used ${plan.used}/${plan.quota} exports this month.\n\nUpgrade your plan for more exports.`);
            window.open(config.dashboardUrl + '/upgrade');
            return;
        }

        if (plan.plan !== 'enterprise' && rowCount > remaining) {
            alert(`You can only export ${remaining} more records this month.\nCurrent data has ${rowCount} records.\n\nUpgrade for more exports.`);
        }

        // Perform export
        const exportCount = Math.min(rowCount, plan.plan === 'enterprise' ? rowCount : remaining);

        if (format === 'csv') {
            table.download("csv", "skill-scraper-results.csv");
        } else {
            table.download("xlsx", "skill-scraper-results.xlsx", { sheetName: "Leads" });
        }

        // Update usage
        await updateUsage(exportCount);

        // Update UI
        updatePlanUI();

        console.log(`Exported ${exportCount} leads.`);
    } catch (e) {
        console.error('Export error:', e);
        alert('Export error: ' + e.message);
    }
}

// CSV download
document.getElementById("download-csv").addEventListener("click", function () {
    checkLoginAndExport('csv');
});

// XLSX download
document.getElementById("download-xlsx").addEventListener("click", function () {
    checkLoginAndExport('xlsx');
});

// Dashboard login
document.getElementById("dashLogin").addEventListener("click", function () {
    chrome.tabs.create({ url: config.dashboardUrl + "/login?ext=true" });
});

// Dashboard signup
document.getElementById("dashSignup").addEventListener("click", function () {
    chrome.tabs.create({ url: config.dashboardUrl + "/login?ext=true" });
});

function flattenObject(a, b = "") {
    const d = {};
    for (const [c, e] of Object.entries(a))
        a = b ? `${b}_${c}` : c,
            "object" === typeof e && null !== e ? Object.assign(d, flattenObject(e, a)) : d[a] = null === e ? "" : e;
    return d;
}

function generateColumns(a) {
    const b = new Set("name phone whatsapp address email website averageRating ratingCount category longitude latitude cid place_id instagram facebook twitter linkedin youtube profileURL".split(" "));
    var d = [];
    b.forEach(c => {
        d.push({ title: capitalizeFirstLetter(c), field: c, width: 300, resizable: true });
    });
    Array.from(a).sort().forEach(c => {
        b.has(c) || d.push({ title: capitalizeFirstLetter(c), field: c, width: 300, resizable: true });
    });
    table.setColumns(d);
}

function showData() {
    chrome.storage.local.get(null, function (a) {
        a = a.leads || [];
        var b = new Set, d = [];
        for (var c = 0; c < a.length; ++c) {
            const e = flattenObject(a[c]);
            d.push(e);
            Object.keys(e).forEach(f => b.add(f));
        }
        generateColumns(b);
        table.setData(d);
    });
}

async function updatePlanUI() {
    try {
        const user = await getCurrentUser();
        const planInfo = document.getElementById('planInfo');
        if (user) {
            const plan = await getUserPlan();
            if (plan) {
                const planConfig = PLANS[plan.plan] || PLANS.free;
                const remaining = plan.plan === 'enterprise' ? '∞' : (plan.quota - (plan.used || 0));
                planInfo.innerHTML = `
                    <span style="color: #8b949e;">${user.email}</span> · 
                    <strong style="color: #00d4ff;">${planConfig.name}</strong> · 
                    <span style="color: #58a6ff;">${remaining} exports left</span>
                `;
            }
        } else {
            planInfo.innerHTML = '<span style="color: #8b949e;">Login to export data</span>';
        }
    } catch (e) {
        console.log('Plan UI error:', e);
    }
}

$(document).ready(function () {
    showData();
    // Update UI check
    updatePlanUI();
});
