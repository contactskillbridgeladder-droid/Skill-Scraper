$manifest = Get-Content manifest.json | ConvertFrom-Json
$version = $manifest.version
$zipName = "skill-scraper-v$version.zip"
Remove-Item -Path "../dashboard/public/$zipName" -ErrorAction SilentlyContinue
Compress-Archive -Path "*" -DestinationPath "../dashboard/public/$zipName" -Force
Write-Host "Created $zipName in dashboard/public/"
