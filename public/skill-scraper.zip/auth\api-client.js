// API client for Skill Scraper Extension
// Uses config.dashboardUrl from config.js (e.g., https://scraper.skillbridgeladder.in)

async function getToken() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(['ext_token'], function (result) {
            resolve(result.ext_token);
        });
    });
}

function isLoggedIn() {
    return getToken().then(token => !!token);
}

function logout() {
    return new Promise((resolve) => {
        chrome.storage.sync.remove(['ext_token'], function () {
            resolve();
        });
    });
}

async function apiGetPlan() {
    const token = await getToken();
    if (!token) throw new Error("Not logged in");

    const res = await fetch(`${config.dashboardUrl}/api/ext/plan`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });

    if (!res.ok) {
        if (res.status === 401) {
            await logout();
            throw new Error("Session expired. Please login again.");
        }
        throw new Error("Failed to fetch plan info");
    }

    return await res.json();
}

async function apiUpdateUsage(count) {
    const token = await getToken();
    if (!token) throw new Error("Not logged in");

    const res = await fetch(`${config.dashboardUrl}/api/ext/usage`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ count })
    });

    if (!res.ok) {
        console.error("Failed to update usage", await res.text());
    }
}

// Global functions matching old signatures (for backwards compatibility with popup/content scripts)

async function getCurrentUser() {
    const token = await getToken();
    if (!token) return null;
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        const payload = JSON.parse(jsonPayload);
        return { email: payload.email, id: payload.sub };
    } catch (e) {
        return null;
    }
}

async function getUserPlan() {
    try {
        return await apiGetPlan();
    } catch (e) {
        console.error("getUserPlan error:", e);
        return null;
    }
}

async function updateUsage(count) {
    try {
        await apiUpdateUsage(count);
    } catch (e) {
        console.error("updateUsage error:", e);
    }
}

async function signOut() {
    await logout();
}
