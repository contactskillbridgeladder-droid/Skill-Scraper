var config = {
    productId: "skillscraper",
    feedback_url: "https://forms.gle/ryakermMciHccHHW6",
    dashboardUrl: "https://scraper.skillbridgeladder.in"
};
