// Automatically sync Supabase token from dashboard localStorage to Extension storage
function autoSyncToken() {
    try {
        const sbKey = Object.keys(localStorage).find(k => k.startsWith('sb-') && k.endsWith('-auth-token'));
        if (sbKey) {
            const tokenData = JSON.parse(localStorage.getItem(sbKey));
            const token = tokenData?.access_token;
            if (token) {
                chrome.storage.sync.get(['ext_token'], function(result) {
                    if (result.ext_token !== token) {
                        chrome.storage.sync.set({ ext_token: token }, function () {
                            console.log("Skill Scraper: Auto-synced login session from dashboard.");
                            try { chrome.runtime.sendMessage({ action: "login_success" }); } catch(e){}
                        });
                    }
                });
            }
        } else {
            // If they logged out of dashboard, logout of extension
            chrome.storage.sync.get(['ext_token'], function(result) {
                if (result.ext_token) {
                    chrome.storage.sync.remove('ext_token');
                    console.log("Skill Scraper: Auto-synced logout.");
                }
            });
        }
    } catch (e) { }
}

// Check on load
autoSyncToken();

// Also listen for explicit manual messages just in case
window.addEventListener("message", function (event) {
    if (event.data && event.data.type === "EXTENSION_LOGIN_SUCCESS") {
        const token = event.data.token;
        chrome.storage.sync.set({ ext_token: token }, function () {
            try { chrome.runtime.sendMessage({ action: "login_success" }); } catch(e){}
            
            // Show proper popup
            const popup = document.createElement("div");
            popup.style.cssText = "position: fixed; top: 20px; right: 20px; background: rgba(0, 240, 255, 0.1); border: 1px solid #00f0ff; color: #00f0ff; padding: 15px 25px; border-radius: 12px; z-index: 999999; font-family: system-ui; font-weight: 600; box-shadow: 0 4px 20px rgba(0,240,255,0.2); backdrop-filter: blur(10px); animation: slideIn 0.3s ease-out;";
            popup.innerHTML = "✅ Login Auto-Synced with Extension!";
            document.body.appendChild(popup);
            setTimeout(() => popup.remove(), 3000);
        });
    }
});
