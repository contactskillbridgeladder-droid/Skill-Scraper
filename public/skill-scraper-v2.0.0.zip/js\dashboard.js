// Skill Scraper - Dashboard Script
// Requires login to export, checks Supabase quota

function capitalizeFirstLetter(a) {
    return a.charAt(0).toUpperCase() + a.slice(1);
}

var table = newTabulator("#example-table", {
    layout: "fitData",
    placeholder: "Loading...",
    selectable: 1,
    downloadConfig: { undefinedString: "" }
});

// Check login and handle export
async function checkLoginAndExport(format) {
    try {
        const user = await getCurrentUser();
        if (!user) {
            // Show login prompt
            document.getElementById('loginPrompt').style.display = 'flex';
            return;
        }

        const showModal = (title, message, redirectUrl = null) => {
            const overlay = document.createElement('div');
            overlay.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:9999; display:flex; align-items:center; justify-content:center;';
            const modal = document.createElement('div');
            modal.style.cssText = 'background:#1a1a2e; border:1px solid #00f0ff; padding:25px; border-radius:12px; max-width:400px; text-align:center; box-shadow:0 10px 30px rgba(0,240,255,0.2);';
            modal.innerHTML = `
                <h3 style="color:#00f0ff; margin-bottom:15px;">${title}</h3>
                <p style="color:#fff; margin-bottom:20px; white-space:pre-wrap; line-height:1.5;">${message}</p>
                <button style="background:linear-gradient(135deg,#00f0ff,#7c3aed); color:#fff; border:none; padding:10px 20px; border-radius:8px; cursor:pointer; font-weight:bold;">${redirectUrl ? 'Upgrade Now' : 'Okay'}</button>
            `;
            modal.querySelector('button').onclick = () => {
                document.body.removeChild(overlay);
                if (redirectUrl) window.open(redirectUrl);
            };
            overlay.appendChild(modal);
            document.body.appendChild(overlay);
        };

        const plan = await getUserPlan();
        if (!plan) {
            showModal('Error', 'Error loading plan info. Please try again.');
            return;
        }

        const remaining = plan.quota - (plan.used || 0);
        const rowCount = table.getRows().length;

        if (plan.plan !== 'enterprise' && remaining <= 0) {
            showModal("Export Limit Reached", `You've used ${plan.used}/${plan.quota} exports this month.\n\nUpgrade your plan for more exports.`, config.dashboardUrl + '/upgrade');
            return;
        }

        if (plan.plan !== 'enterprise' && rowCount > remaining) {
            showModal("Warning", `You can only export ${remaining} more records this month.\nCurrent data has ${rowCount} records.\n\nUpgrade for more exports.`, config.dashboardUrl + '/upgrade');
        }

        // Perform export
        const exportCount = Math.min(rowCount, plan.plan === 'enterprise' ? rowCount : remaining);

        if (format === 'csv') {
            table.download("csv", "skill-scraper-results.csv");
        } else {
            table.download("xlsx", "skill-scraper-results.xlsx", { sheetName: "Leads" });
        }

        // Update usage
        await updateUsage(exportCount);

        // Update UI
        updatePlanUI();

        console.log(`Exported ${exportCount} leads.`);
    } catch (e) {
        console.error('Export error:', e);
        alert('Export error: ' + e.message);
    }
}

// CSV download
document.getElementById("download-csv").addEventListener("click", function () {
    checkLoginAndExport('csv');
});

// XLSX download
document.getElementById("download-xlsx").addEventListener("click", function () {
    checkLoginAndExport('xlsx');
});

// Filter No Website
let isFilteredNoWebsite = false;
document.getElementById("filter-no-website").addEventListener("click", function () {
    if (!isFilteredNoWebsite) {
        table.setFilter(function(data){
            return !data.website || data.website.trim() === "";
        });
        this.innerHTML = "🌐 Show All";
        this.style.background = "#58a6ff";
        isFilteredNoWebsite = true;
    } else {
        table.clearFilter();
        this.innerHTML = "🌐 Show No Website";
        this.style.background = "#2a2a35";
        isFilteredNoWebsite = false;
    }
});

// Dashboard login
document.getElementById("dashLogin").addEventListener("click", function () {
    chrome.tabs.create({ url: config.dashboardUrl + "/login?ext=true" });
});

// Dashboard signup
document.getElementById("dashSignup").addEventListener("click", function () {
    chrome.tabs.create({ url: config.dashboardUrl + "/login?ext=true" });
});

function flattenObject(a, b = "") {
    const d = {};
    for (const [c, e] of Object.entries(a))
        a = b ? `${b}_${c}` : c,
            "object" === typeof e && null !== e ? Object.assign(d, flattenObject(e, a)) : d[a] = null === e ? "" : e;
    return d;
}

function generateColumns(a) {
    const b = new Set("name phone whatsapp address email website averageRating ratingCount category longitude latitude cid place_id instagram facebook twitter linkedin youtube profileURL".split(" "));
    var d = [];
    b.forEach(c => {
        d.push({ title: capitalizeFirstLetter(c), field: c, width: 300, resizable: true });
    });
    Array.from(a).sort().forEach(c => {
        b.has(c) || d.push({ title: capitalizeFirstLetter(c), field: c, width: 300, resizable: true });
    });
    table.setColumns(d);
}

function showData() {
    chrome.storage.local.get(null, function (a) {
        a = a.leads || [];
        var b = new Set, d = [];
        for (var c = 0; c < a.length; ++c) {
            const e = flattenObject(a[c]);
            d.push(e);
            Object.keys(e).forEach(f => b.add(f));
        }
        generateColumns(b);
        table.setData(d);
    });
}

async function updatePlanUI() {
    try {
        const user = await getCurrentUser();
        const planInfo = document.getElementById('planInfo');
        if (user) {
            const plan = await getUserPlan();
            if (plan) {
                const planConfig = PLANS[plan.plan] || PLANS.free;
                const remaining = plan.plan === 'enterprise' ? '∞' : (plan.quota - (plan.used || 0));
                planInfo.innerHTML = `
                    <span style="color: #8b949e;">${user.email}</span> · 
                    <strong style="color: #00d4ff;">${planConfig.name}</strong> · 
                    <span style="color: #58a6ff;">${remaining} exports left</span>
                `;
            }
        } else {
            planInfo.innerHTML = '<span style="color: #8b949e;">Login to export data</span>';
        }
    } catch (e) {
        console.log('Plan UI error:', e);
    }
}

$(document).ready(function () {
    showData();
    // Update UI check
    updatePlanUI();
});
