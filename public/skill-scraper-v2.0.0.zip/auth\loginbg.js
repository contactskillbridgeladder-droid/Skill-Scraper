// login click → open dashboard login page & inject token listener
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg.action === "login") {
        const url = config.dashboardUrl + "/login?ext=true";
        chrome.tabs.create({ url: url }, function (tab) {
            // Inject lcs.js to listen for EXTENSION_LOGIN_SUCCESS postMessage
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ["lcs.js"]
            });
        });
    }
});
